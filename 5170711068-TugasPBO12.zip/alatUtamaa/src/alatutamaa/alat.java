package alatutamaa;

public class alat {
    String namaAlat;
    String merkAlat;
    String warnaAlat;
    public double hargaAlat;
    
    void nama(String nama){
        this.namaAlat = nama;
    }
    
    void merk(String merk){
        this.merkAlat = merk;
    }
    
    void hargaBeli(double harga){
        this.hargaAlat = harga;
    }
    
    void warna(String warna){
        this.warnaAlat = warna;
    }
}

