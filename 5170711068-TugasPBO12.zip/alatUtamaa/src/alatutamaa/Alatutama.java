package alatutamaa;

import java.util.Scanner;

public class Alatutama {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int jml, pilih;

        Alattulis pensil = new Alattulis();
        Alattulis sabun = new Alattulis();
        Alattulis obat = new Alattulis();
        System.out.print("Masukan jumlah : ");
        jml = sc.nextInt();
        for (int i = 0; i < jml; i++) {
            System.out.println(" JENIS ALAT ");
            System.out.println("1. Alat mandi");
            System.out.println("2. Alat tulis");
            System.out.println("3. Alat kesehatan");
            System.out.print("Masukan pilihan anda : ");
            pilih = sc.nextInt();
            System.out.println("");
            System.out.println("Data ke = " + (i + 1));
            if (pilih == 1) {
                System.out.println("Alat Mandi");
                System.out.print("Masukan nama barang :");
                String nama = sc.next();
                sabun.nama(nama);
                System.out.print("Masukan harga : ");
                double harga = sc.nextDouble();
                sabun.hargaBeli(harga);
                System.out.print("Masukan produk(merk) : ");
                String merk = sc.next();
                sabun.merk(merk);
                System.out.print("Warna :");
                String warna = sc.next();
                sabun.warna(warna);
                System.out.print("Wujudnya : ");
                int s = sc.nextInt();
                sabun.wujud(s);
                
                System.out.println("");
                System.out.println("======Kui Tansi======");
                System.out.println("Nama alat : " + sabun.namaAlat);
                System.out.println("Harga alat : " + sabun.hargaAlat);
                System.out.println("Merknya : " + sabun.merkAlat);
                System.out.println("Warnanya : " + sabun.warnaAlat);
                System.out.println("Wujudnya alat :" + sabun.s);
            }
            System.out.println("");
            if (pilih == 2) {
                System.out.println("Alat Tulis");
                System.out.print("Masukan nama barang : ");
                String nama = sc.next();
                pensil.nama(nama);
                System.out.print("Masukan harga : ");
                double harga = sc.nextDouble();
                pensil.hargaBeli(harga);
                System.out.print("Masukan produk(merk) : ");
                String merk = sc.next();
                pensil.merk(merk);
                pensil.fungsi();
                System.out.print("Masukan dimensi p & l : ");
                int p = sc.nextInt();
                int l = sc.nextInt();
                pensil.dimensi(p, l);
                
                System.out.println("");
                System.out.println("======Kui Tansi======");
                System.out.println("Nama alat : " + pensil.namaAlat);
                System.out.println("Harga alat : " + pensil.hargaAlat);
                System.out.println("Merknya : " + pensil.merkAlat);
                System.out.println("fungsi : " + pensil.fungsiAlat);
                System.out.println("Dimensinya alat :" + pensil.l);
            }
            System.out.println("");
            if (pilih == 3){
            System.out.println("Alat Kesehatan");
            System.out.print("Masukan nama barang : ");
            String nama = sc.next();
            obat.nama(nama);
            System.out.print("Masukan harga : ");
            double harga = sc.nextDouble();
            obat.hargaBeli(harga);
            System.out.print("Masukan produk(merk) : ");
            String merk = sc.next();
            obat.merk(merk);
            System.out.print("jenis alat : ");
            String jenis = sc.next();
            obat.jenis();
            obat.manfaat();
            
            System.out.println("======kwitansi indoapril======");
            System.out.println("Alat Kesehatan");
            System.out.println("Nama alat : " +obat.namaAlat);
            System.out.println("Harga alat : " +obat.hargaAlat);
            System.out.println("Merknya : " +obat.merkAlat);
            System.out.println("Jenis : " +obat.jenisAlat);
            System.out.println("Manfaat alat : "+obat.manfaatAlat);
        }
            }
        }
    }

