package alatutamaa;
import alatutamaa.alat;
import java.util.Scanner;
public class Alattulis extends alat {
     String fungsiAlat;
     String manfaatAlat;
     String jenisAlat;
     public int l,s;
    String p;
   
   void fungsi(){
       Scanner sc = new Scanner(System.in);
       System.out.print("input fungsi : ");
       this.fungsiAlat = sc.next();
   }
   
   void dimensi(int pjg, int lbr){
       this.l = pjg*lbr;
   }

   void wujud(int sisi){
       this.s = sisi*sisi;
   }
    
   void jenis(){
       Scanner sc = new Scanner(System.in);
       System.out.print("input jenis : ");
       this.jenisAlat = sc.next();
   }
   void manfaat(){
       Scanner sc = new Scanner(System.in);
       System.out.print("input manfaat : ");
       this.manfaatAlat = sc.next();
   }
    
}

    

